package com.cyntaks.GDXGIDE.code;

import org.antlr.runtime.tree.Tree;

import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.cyntaks.GDXGIDE.*;
import com.cyntaks.GDXGIDE.config.CellConfig;
import com.cyntaks.GDXGIDE.gui.CellDisplay;
import com.cyntaks.GDXGIDE.gui.ContentLine;
import com.cyntaks.GDXGIDE.gui.GridDisplay;
import com.cyntaks.GDXGIDE.input.GridInputHandler;
import com.cyntaks.GDXGIDE.text.GLString;
import com.cyntaks.GDXGIDE.util.GLImage;

public class CodeCell2 extends Cell {
	private boolean debug = false;
	private GLString code;
	private GLString title;
	private GLImage image;
	private boolean embedded;
	private boolean textCell;
	private float textWidth;
	private float textHeight;
	private Window window;
	
	public CodeCell2(Grid owner, Tree node, boolean embedded) {
		super(owner, node);
		this.embedded = embedded;
	}
	
	public void init() {
		CellConfig config = super.getConfig();
		
		image.setWidth(210);
		image.setHeight(210);
		image.setDebug(debug);
		
		title = new GLString(getNode().getText(), config.getTitleTypeFace(), config.getTitleFontStyle(), config.getTitleFontSize(), config.getTitleFontColor());
		title.setHorizontalAlignment(GLString.CENTER);
		title.setVerticalAlignment(GLString.TOP);
		title.setDebug(debug);
		title.setLockFontSize(true);
		
		buildContents();
		
		ContentLine middleVertLine = super.getDisplay().getContentLine(CellDisplay.LAYER_MIDDLE, CellDisplay.LINE_X_CENTER);
		middleVertLine.setAttachLocation(ContentLine.ATTACH_BEGINNING);
		if(!textCell) {
			middleVertLine.add(title);
			middleVertLine.add(window);
		} else
			middleVertLine.add(code);
		
		ContentLine line = super.getDisplay().getContentLine(CellDisplay.LAYER_TOP, CellDisplay.LINE_RIGHT);
		line.setAttachLocation(ContentLine.ATTACH_MIDDLE);
		//line.add(image);
	}
	
	private void buildContents() {
		Tree node = super.getNode();
		CellConfig config = super.getConfig();
		if(ATreeUtils.isLeaf(node) || embedded) {
			GLString codeString = new GLString(node.getText(), config.getTypeFace(), config.getFontStyle(), config.getFontSize(), config.getFontColor());
			codeString.setHorizontalAlignment(GLString.LEFT);
			codeString.setVerticalAlignment(GLString.TOP);
			codeString.setLockFontSize(false);
			codeString.setDebug(debug);
			textCell = true;
			textWidth = codeString.getTextWidth();
			textHeight = codeString.getTextHeight();
			resize(textWidth, textHeight);
			this.code = codeString;
			this.setDebug(true);
		} else {
			Window bounds = new Window();
			CodeGrid grid = new CodeGrid();

			grid.setEmbedded(true);
			grid.setCellConfig(super.getConfig());
			bounds.setGrid(grid);
			
			grid.configureAppearance(GridDisplay.VERTICAL, 1, 1, 0);
			grid.setInputHandler(new GridInputHandler(grid));
			TreeManager manager = new TreeManager(node, grid);
			grid.getInputHandler().setTreeManager(manager);
			
			bounds.setDebug(false);
			bounds.setSkipScissor(true);
			bounds.load();
			
			grid.activate();

			textWidth = title.getTextWidth();
			textHeight = title.getTextHeight();
			resize(textWidth, textHeight);
			
			window = bounds;
		}
	}
	
	public void load() {
		super.load();

		int rand = (int)(Math.random()*4 + 1);
		ResourceManager.loadTexture("images/Star_Wars_00" + rand + ".png", "sw" + rand, TextureFilter.Linear);
		image = new GLImage(ResourceManager.getTexture("sw" + rand));
		
		init();
	}
	
	public void resize(float width, float height) {
		super.resize(width, height);
		
		super.getUnderGraphic().setWidth(width);
		super.getUnderGraphic().setHeight(height);
	}
	
	public boolean isEmbedded() {
		return embedded;
	}
	
	public boolean isTextCell() {
		return textCell;
	}
	
	public void update(float delta) {
		super.update(delta);
		fitToContents();
	}
	
	public void fitToContents() {
		if(isTextCell() || isEmbedded()) {
			resize(textWidth, textHeight);
		}
		else {
			window.fitToGrid();
			resize(window.getWidth() == textWidth ? window.getWidth() : textWidth, window.getHeight() + textHeight);
		}
	}
}