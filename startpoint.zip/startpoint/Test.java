@Author(
   name = "Benjamin Franklin",
   date = "3/27/2003"
)

@Blah(
   test1 = "benwho?",
   test2 = "hrm"
)

package com.cyntaks.GDXGIDE;

import javax.swing.*;
import java.awt;
import javax.media.*;

public class Test {

	
}


class Test2 {
	private int x;

	public Test2() {
		System.out.println("this is a test");
	}

	public int TestBlah() {
		System.out.println("this is another test");
		return -1;
	}

	public void blah(int z) {
		int r = z + 3;
	}
}